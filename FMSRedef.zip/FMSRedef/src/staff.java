/** author @ Shreyash Arya (2015097)h
	    Tushita Rathore (2015108)
*/
import java.util.*;
public class staff extends User{

	private String department;
	
	public staff()
	{
		
	}

	public void setDepartment(String x)
	{
		department = x;
	}
	
	public String getDepartment()
	{
		return department;
	}
	
	public void sendLogrequests()
	{
		
	}
	
	public void sendLeave()
	{
		
	}
	
	
	
	public void statusofStaffer()
	{
		
	}
	
	public void updateTaskstatus()
	{
		
	}
	
	public void generateTaskReport()
	{
		
	}	

}

