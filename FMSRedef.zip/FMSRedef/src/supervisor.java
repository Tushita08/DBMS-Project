/** author @ Shreyash Arya (2015097)h
	    Tushita Rathore (2015108)
*/
import java.util.*;

public class supervisor extends User {

	private String department;
	
	public supervisor()
	{
		
	}

	public void setDepartment(String x)
	{
		department = x;
	}
	
	public String getDepartment()
	{
		return department;
	}
	
	public void add()
	{
		
	}
	
	public void view()
	{
		
	}
	
	public void delete()
	{
		
	}
	

	public void assignTask()
	{
		
	}
	
	
	public void logisticsUpdates()
	{
		
	}
	
	public int toolsRequests()
	{
		return 0;
	}
	
	public void sendLogrequests()
	{
		
	}
	
	public void sendLeave()
	{
		
	}
	
	public void viewReports()
	{
		
	}
	
	List<String> storeditems;
	
}
