/** author @ Shreyash Arya (2015097)h
	    Tushita Rathore (2015108)
*/
public class forRequests {
	
	private String name;
	private String post;
	private String username;
	private String password;
	private String dob;
	private String adr;
	private String dep;
	

	
	public forRequests()
	{
		
	}
	
	public void setName(String x)
	{
		name = x;
	}
	
	public String getName()
	{
		return name;
	}

	public void setPost(String x)
	{
		post = x;
	}
	
	public String getPost()
	{
		return post;
	}

	public void setUsername(String x)
	{
		username = x;
	}
	
	public String getUsername()
	{
		return username;
	}
	
	public void setPassword(String y)
	{
		password = y;
	}
	
	public String getPassword()
	{
		return password;
	}
	
	public void setDOB(String x)
	{
		dob = x;
	}
	
	public String getDOB()
	{
		return dob;
	}
	
	public void setDep(String x)
	{
		dep = x;
	}
	
	public String getDep()
	{
		return dep;
	}
	
	public void setAdr(String x)
	{
		adr = x;
	}
	
	public String getAdr()
	{
		return adr;
	}

}
