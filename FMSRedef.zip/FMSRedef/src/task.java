/** author @ Shreyash Arya (2015097)h
	    Tushita Rathore (2015108)
*/
import java.util.*;
public class task {

	private String taskid;
	private String taskname;
	private String descp;
	private String department;
	private String[] equip = new String[100];
	
	
	public void NameofTask()
	{
		
	}
	
	public int taskId()
	{
		return 0;
	}
	
	public void taskDescp()
	{
		
	}
	
	public void department()
	{
		
	}
	
	public int taskStatus()
	{
		return 0;
	}
	
	public int deadline()
	{
		return 0;
	}
	
	public void equipReq()
	{
		
	}
	
	
}
