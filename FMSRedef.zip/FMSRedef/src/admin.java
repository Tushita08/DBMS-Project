/** author @ Shreyash Arya (2015097)h
	    Tushita Rathore (2015108)
*/
import java.util.*;
public class admin extends User {
	
	public admin()
	{
		
	}
	
	public void add()
	{
		
	}
	
	public void view()
	{
		
	}
	
	public void delete()
	{
		
	}
	
	public void assignTask()
	{
		task t1 = new task();
		task t2 = new task();
	}
	
	public void logisticRequests()
	{
		
	}
	

}
