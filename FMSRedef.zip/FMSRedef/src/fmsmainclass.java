/** author @ Shreyash Arya (2015097)h
	    Tushita Rathore (2015108)
*/

import java.io.IOException;
import java.util.*;

import javax.swing.JFrame;
public class fmsmainclass{
	
	
	public fmsmainclass() throws IOException
	{

		login start = new login();
		
		
	}
	
	public static void main(String args[]) throws IOException
	{
		
		fmsmainclass fmc = new fmsmainclass();
		
	}
	
	public int DepartmentId()
	{
		return 0;
	}

	
	
		
	
}